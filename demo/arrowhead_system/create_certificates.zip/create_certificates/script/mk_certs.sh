#!/bin/bash

cd "$(dirname "$0")" || exit
source "mylib_certs.sh"
cd ..


# ENTITIES
#
#   keystore: private and public keys which identify us
#     A Java keystore is a file, which stores private key entries, certificates with
#     public keys or just secret keys. It stores each by an alias for ease of lookup.
#     Keystores hold keys that our application owns that we can use to prove the
#     integrity of a message and the authenticity of the sender, say by signing payloads.
#
#   truststore: public keys and certificates that identify others
#     e.g. We request a server (SSL). We a server certificate with a public key chain.
#     We look up from last public key (that of the server) if it is in our truststore
#     if not, we try the next one ... If we found a public key in the key chain, which
#     is in our truststore, then we verify down all other keys down to the public server
#     key again ...
#
#
# ORGANIZATION UNITS
#
#   root:
#     The base organization ...
#   system:
#     An arrowhead core system ...
#   cloud:
#     A local cloud with arrowhead core and application systems ...
#   consumer:
#     An arrowhead application system, which consumes data ...
#   provider:
#     An arrowhead application system, which provides data ...
#   sysop:
#     A system operator ... Typical usage of sysop certificate is by front end
#     applications running in a web browser


# ROOT

create_root_keystore \
  "crypto/root.p12" "arrowhead.eu"

create_cloud_keystore \
  "crypto/root.p12" "arrowhead.eu" \
  "crypto/quickstart.p12" "quickstart.python.arrowhead.eu"

create_consumer_system_keystore() {
  SYSTEM_NAME=$1

  create_system_keystore \
    "crypto/root.p12" "arrowhead.eu" \
    "crypto/quickstart.p12" "quickstart.python.arrowhead.eu" \
    "crypto/${SYSTEM_NAME}.p12" "${SYSTEM_NAME}.quickstart.python.arrowhead.eu" \
    "dns:core.consumer,ip:172.23.2.13,dns:localhost,ip:127.0.0.1"
}

create_consumer_system_keystore "authorization"
create_consumer_system_keystore "service_registry"
create_consumer_system_keystore "orchestrator"
create_consumer_system_keystore "quickstart-consumer"
create_consumer_system_keystore "quickstart-provider"

create_sysop_keystore \
  "crypto/root.p12" "arrowhead.eu" \
  "crypto/quickstart.p12" "quickstart.python.arrowhead.eu" \
  "crypto/sysop.p12" "sysop.quickstart.python.arrowhead.eu"

create_truststore \
  "crypto/truststore.p12" \
  "crypto/quickstart.crt" "quickstart.python.arrowhead.eu"

openssl pkcs12 -in crypto/quickstart-consumer.p12 -clcerts -nokeys -out crypto/quickstart-consumer.crt
openssl pkcs12 -in crypto/quickstart-consumer.p12 -nocerts -nodes -out crypto/quickstart-consumer.key
openssl pkcs12 -in crypto/quickstart-provider.p12 -clcerts -nokeys -out crypto/quickstart-provider.crt
openssl pkcs12 -in crypto/quickstart-provider.p12 -nocerts -nodes -out crypto/quickstart-provider.key
