

#docker pull nginx

#docker run -it nginx /bin/bash

#docker run -it --rm nginx cat /etc/nginx/nginx.conf > nginx.conf
#scite nginx.conf

# copy a file out of a docker image
# from https://stackoverflow.com/questions/25292198/docker-how-can-i-copy-a-file-from-an-image-to-a-host:
#   - create a temporary docker container
#   - copy the file
#   - remove the temporary container
id=$(docker create svetlint/serviceregistry)
docker cp $id:/serviceregistry/arrowhead-serviceregistry.jar - > arrowhead-serviceregistry.jar
docker rm -v $id

id=$(docker create svetlint/orchestrator)
docker cp $id:/orchestrator/arrowhead-orchestrator.jar - > arrowhead-orchestrator.jar
docker rm -v $id

id=$(docker create svetlint/authorization)
docker cp $id:/authorization/arrowhead-authorization.jar - > arrowhead-authorization.jar
docker rm -v $id
